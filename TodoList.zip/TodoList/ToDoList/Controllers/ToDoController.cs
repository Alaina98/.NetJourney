﻿using Microsoft.AspNetCore.Mvc;
using ToDoList.Data;
using ToDoList.Models;

namespace ToDoList.Controllers
{
    public class ToDoController : Controller
    {
        private readonly ApplicationDBContext _db;
        public ToDoController(ApplicationDBContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            var todoObj=_db.todos.ToList();
            return View(todoObj);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(ToDo obj)
        {
            _db.todos.Add(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}
