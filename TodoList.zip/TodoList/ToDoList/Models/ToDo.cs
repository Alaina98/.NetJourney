﻿namespace ToDoList.Models
{
    public class ToDo
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
