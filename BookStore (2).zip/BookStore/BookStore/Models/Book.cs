﻿namespace BookStore.Models
{
    public class Book
    {
        public int id { get; set; }
        public string B_name { get; set; }
        public string B_Type { get; set;}
        public string B_Author { get; set; }
        public string B_Description { get; set;}

    }
}
