﻿using BookStore.Models;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    public class ViewBController : Controller
    {
        private readonly ApplicationDBContext _db;
        public ViewBController(ApplicationDBContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            List<Book> viewObj=_db.Books.ToList();
            return View(viewObj);
        }
        public IActionResult create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult create(Book obj)
        {
            _db.Books.Add(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Update(int ID)
        {

      

            var todoobj = _db.Books.FirstOrDefault(b => b.id == ID);
            return View(todoobj);
        }
        [HttpPost]
        public IActionResult Update(Book obj)
        {

            _db.Books.Update(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int ID)
        {
            var todoobj = _db.Books.FirstOrDefault(b => b.id == ID);
            _db.Books.Remove(todoobj);
            _db.SaveChanges();

            return RedirectToAction("Index");

        }
    }
}
